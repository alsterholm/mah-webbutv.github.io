Information till inl�mngningsuppgift 2
======================================

Filerna �r ihopkopplade enligt:

html1.html -> Anv�der stylesheetet style1.css
html2.html -> Anv�der stylesheetet style2.css
html3.html -> Anv�der stylesheetet style3.css

Bilderna ni ska anv�nda till den f�rsta designen �r:
- background.png -> Ska anv�ndas som bakgrundsbild f�r sidan (body)
- background_h1.png -> Ska anv�ndas som bakgrundsbild f�r h1-rubrikerna